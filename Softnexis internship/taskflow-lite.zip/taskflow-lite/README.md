# TaskFlow Lite 🚀

A browser-based Task Manager built with Vanilla JavaScript.

## Features
- Add tasks
- Delete tasks
- Toggle completion
- Filter tasks (All / Active / Completed)
- Persistent storage with localStorage
- Input validation

## Run Project
Just open `index.html` in browser.
